@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if "%~1"=="" exit /b 20
if "%~2"=="" exit /b 21

set "RIAS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%RIAS_POWERSHELL%" (
  >"%~2" echo ERREUR_IA=Windows PowerShell est introuvable sur ce PC.
  exit /b 22
)
if not exist "%~dp0MOTEUR_IA.ps1" (
  >"%~2" echo ERREUR_IA=Le fichier MOTEUR_IA.ps1 manque. Decompresse de nouveau toute l archive.
  exit /b 23
)

"%RIAS_POWERSHELL%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0MOTEUR_IA.ps1" -PromptPath "%~1" -ResultPath "%~2"
set "RIAS_ENGINE_EXIT=%ERRORLEVEL%"
exit /b %RIAS_ENGINE_EXIT%

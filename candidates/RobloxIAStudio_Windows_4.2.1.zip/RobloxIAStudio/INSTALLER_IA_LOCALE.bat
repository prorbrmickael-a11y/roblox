@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
chcp 65001 >nul
title Installation et test de l'IA locale - RIAS Creator Studio 4.2.1

echo ============================================================
echo   RIAS CREATOR STUDIO 4.2.1 - INSTALLATION VERIFIEE
echo ============================================================
echo.
echo Modele : Qwen 3.5 9B Q4_K_M
echo Taille : environ 6,6 Go + Ollama
echo Conseil : Windows 10/11 64 bits, 16 Go de RAM recommandes.
echo Toutes les generations resteront ensuite sur ce PC.
echo.
if not defined RIAS_NONINTERACTIVE pause

set "OLLAMA_EXE="
for /f "delims=" %%I in ('where ollama.exe 2^>nul') do if not defined OLLAMA_EXE set "OLLAMA_EXE=%%I"

if not defined OLLAMA_EXE if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
if not defined OLLAMA_EXE if exist "%LOCALAPPDATA%\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Ollama\ollama.exe"
if not defined OLLAMA_EXE if exist "%ProgramFiles%\Ollama\ollama.exe" set "OLLAMA_EXE=%ProgramFiles%\Ollama\ollama.exe"

if not defined OLLAMA_EXE (
  where winget.exe >nul 2>&1
  if errorlevel 1 goto :NO_WINGET
  echo Installation officielle d'Ollama...
  winget install --id Ollama.Ollama --exact --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :INSTALL_FAILED
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
  if not defined OLLAMA_EXE if exist "%LOCALAPPDATA%\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Ollama\ollama.exe"
  if not defined OLLAMA_EXE if exist "%ProgramFiles%\Ollama\ollama.exe" set "OLLAMA_EXE=%ProgramFiles%\Ollama\ollama.exe"
)

if not defined OLLAMA_EXE goto :INSTALL_FAILED

echo.
echo Demarrage et verification du serveur Ollama...
call :ENSURE_SERVER
if errorlevel 1 goto :SERVER_FAILED

echo.
echo Telechargement de Qwen 3.5 9B. Ne fermez pas cette fenetre.
echo Cette etape peut etre longue selon la connexion Internet.
"%OLLAMA_EXE%" pull qwen3.5:9b
if errorlevel 1 goto :MODEL_FAILED

echo.
echo Verification du modele...
"%OLLAMA_EXE%" show qwen3.5:9b >nul
if errorlevel 1 goto :MODEL_FAILED

echo.
echo Optimisation du modele pour la programmation Roblox...
set "RIAS_MODELFILE=%TEMP%\RobloxIAStudio_Modelfile.txt"
>"%RIAS_MODELFILE%" echo FROM qwen3.5:9b
>>"%RIAS_MODELFILE%" echo PARAMETER num_ctx 16384
>>"%RIAS_MODELFILE%" echo PARAMETER temperature 0.25
>>"%RIAS_MODELFILE%" echo PARAMETER top_p 0.9
"%OLLAMA_EXE%" create roblox-ai-studio -f "%RIAS_MODELFILE%"
if errorlevel 1 goto :MODEL_FAILED
del "%RIAS_MODELFILE%" >nul 2>&1

"%OLLAMA_EXE%" show roblox-ai-studio >nul
if errorlevel 1 goto :MODEL_FAILED

echo.
echo Test reel de generation avec le meme moteur que l'application...
set "RIAS_TEST_PROMPT=%TEMP%\RIAS_install_prompt_%RANDOM%_%RANDOM%.txt"
set "RIAS_TEST_RESULT=%TEMP%\RIAS_install_result_%RANDOM%_%RANDOM%.txt"
>"%RIAS_TEST_PROMPT%" echo Reponds uniquement par IA_LOCALE_OK
call "%~dp0MOTEUR_IA.bat" "%RIAS_TEST_PROMPT%" "%RIAS_TEST_RESULT%"
set "RIAS_REAL_TEST_EXIT=!ERRORLEVEL!"
if not "!RIAS_REAL_TEST_EXIT!"=="0" goto :REAL_TEST_FAILED
findstr /i /c:"IA_LOCALE_OK" "%RIAS_TEST_RESULT%" >nul 2>&1
if errorlevel 1 goto :REAL_TEST_FAILED
del "%RIAS_TEST_PROMPT%" >nul 2>&1
del "%RIAS_TEST_RESULT%" >nul 2>&1

echo.
echo ============================================================
echo Installation terminee avec succes.
echo Le profil roblox-ai-studio est pret avec un contexte de 16 384 tokens.
echo Une vraie reponse du modele a ete recue et verifiee.
echo Tu peux maintenant lancer RobloxIAStudio.exe.
echo ============================================================
if not defined RIAS_NONINTERACTIVE pause
exit /b 0

:ENSURE_SERVER
"%OLLAMA_EXE%" list >nul 2>&1
if not errorlevel 1 exit /b 0
start "" /b "%OLLAMA_EXE%" serve >nul 2>&1
for /l %%N in (1,1,40) do (
  timeout /t 2 /nobreak >nul 2>&1
  "%OLLAMA_EXE%" list >nul 2>&1
  if not errorlevel 1 exit /b 0
)
exit /b 1

:NO_WINGET
echo.
echo Winget n'est pas disponible sur ce PC.
echo Installe Ollama depuis https://ollama.com/download/windows
echo puis relance ce fichier.
if not defined RIAS_NONINTERACTIVE pause
exit /b 2

:INSTALL_FAILED
echo.
echo L'installation d'Ollama a echoue.
echo Installe-le depuis https://ollama.com/download/windows puis relance ce fichier.
if not defined RIAS_NONINTERACTIVE pause
exit /b 3

:SERVER_FAILED
echo.
echo Le serveur Ollama ne repond pas apres 80 secondes.
echo Redemarre Windows, puis relance cet installateur.
if not defined RIAS_NONINTERACTIVE pause
exit /b 5

:MODEL_FAILED
echo.
echo Le telechargement du modele a echoue ou a ete interrompu.
echo Verifie l'espace disque et la connexion, puis relance ce fichier.
if not defined RIAS_NONINTERACTIVE pause
exit /b 4

:REAL_TEST_FAILED
echo.
echo Le modele est installe mais le test de generation a echoue.
if exist "%RIAS_TEST_RESULT%" type "%RIAS_TEST_RESULT%"
del "%RIAS_TEST_PROMPT%" >nul 2>&1
del "%RIAS_TEST_RESULT%" >nul 2>&1
echo Relance TESTER_IA_LOCALE.bat pour obtenir un journal complet.
if not defined RIAS_NONINTERACTIVE pause
exit /b 6

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
title Diagnostic reel - RIAS Creator Studio 4.2.1

set "RIAS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%RIAS_POWERSHELL%" (
  echo ECHEC : Windows PowerShell est introuvable.
  set "RIAS_TEST_EXIT=22"
  goto :END
)
if not exist "%~dp0TESTER_IA_LOCALE.ps1" (
  echo ECHEC : TESTER_IA_LOCALE.ps1 est absent. Decompresse toute l archive avant le test.
  set "RIAS_TEST_EXIT=23"
  goto :END
)

"%RIAS_POWERSHELL%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TESTER_IA_LOCALE.ps1"
set "RIAS_TEST_EXIT=%ERRORLEVEL%"

:END
echo.
if not defined RIAS_NONINTERACTIVE pause
exit /b %RIAS_TEST_EXIT%

param(
    [switch]$SkipApplicationLaunch,
    [switch]$SkipOnlineUpdate
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$LogPath = Join-Path $env:TEMP ('RIAS-Diagnostic-' + $Stamp + '.txt')
$script:Failures = 0
$script:LogLines = @()

function Add-Line([string]$Text, [ConsoleColor]$Color = [ConsoleColor]::Gray) {
    Write-Host $Text -ForegroundColor $Color
    $script:LogLines += $Text
}

function Pass([string]$Name, [string]$Detail = '') {
    $Line = '[OK] ' + $Name
    if ($Detail) { $Line += ' - ' + $Detail }
    Add-Line $Line Green
}

function Fail([string]$Name, [string]$Detail) {
    $script:Failures++
    Add-Line ('[ECHEC] ' + $Name + ' - ' + $Detail) Red
}

function Info([string]$Text) {
    Add-Line ('[INFO] ' + $Text) Cyan
}

function Remove-Safely([string]$Path) {
    if ($Path -and (Test-Path -LiteralPath $Path)) {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Get-Sha256([string]$Path) {
    $Stream = [IO.File]::OpenRead($Path)
    $Algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        $Bytes = $Algorithm.ComputeHash($Stream)
        return ([BitConverter]::ToString($Bytes)).Replace('-', '')
    } finally {
        $Algorithm.Dispose()
        $Stream.Dispose()
    }
}

Add-Line '============================================================' DarkCyan
Add-Line ' RIAS CREATOR STUDIO 4.2.1 - DIAGNOSTIC REEL' Cyan
Add-Line '============================================================' DarkCyan
Info ('Date : ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss K'))
Info ('Windows PowerShell : ' + $PSVersionTable.PSVersion.ToString())
Info ('Dossier : ' + $Root)

$RequiredFiles = @(
    'RobloxIAStudio.exe',
    'MOTEUR_IA.bat',
    'MOTEUR_IA.ps1',
    'Updater\Update.ps1',
    'update-channel.json',
    'RobloxIAStudioPlugin.rbxmx',
    'Dashboard\index.html',
    'Dashboard\DashboardServer.ps1'
)
$Missing = @($RequiredFiles | Where-Object { -not (Test-Path -LiteralPath (Join-Path $Root $_) -PathType Leaf) })
if ($Missing.Count -eq 0) {
    Pass 'Archive decompressee' 'tous les fichiers indispensables sont presents'
} else {
    Fail 'Archive decompressee' ('fichiers manquants : ' + ($Missing -join ', '))
}

try {
    [xml]$Plugin = Get-Content -LiteralPath (Join-Path $Root 'RobloxIAStudioPlugin.rbxmx') -Raw -Encoding UTF8
    $SourceNode = $Plugin.SelectSingleNode('//ProtectedString[@name="Source"]')
    if ($SourceNode -and $SourceNode.InnerText -match 'RIAS_GeneratedWorld') {
        Pass 'Plugin Roblox Studio' 'XML lisible et source integree'
    } else {
        Fail 'Plugin Roblox Studio' 'la source Luau attendue est absente'
    }
} catch {
    Fail 'Plugin Roblox Studio' $_.Exception.Message
}

if (-not $SkipApplicationLaunch) {
    $Process = $null
    try {
        $Process = Start-Process -FilePath (Join-Path $Root 'RobloxIAStudio.exe') -WorkingDirectory $Root -PassThru
        Start-Sleep -Seconds 3
        $Process.Refresh()
        if ($Process.HasExited) {
            Fail 'Demarrage de l application' ('fermeture immediate, code ' + $Process.ExitCode)
        } else {
            Pass 'Demarrage de l application' 'processus Windows actif apres 3 secondes'
        }
    } catch {
        Fail 'Demarrage de l application' $_.Exception.Message
    } finally {
        if ($Process -and -not $Process.HasExited) {
            try { $null = $Process.CloseMainWindow() } catch { }
            try {
                if (-not $Process.WaitForExit(5000)) { Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue }
            } catch { Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue }
        }
    }
} else {
    Info 'Demarrage graphique ignore sur demande.'
}

$PromptPath = Join-Path $env:TEMP ('RIAS-Test-Prompt-' + [Guid]::NewGuid().ToString('N') + '.txt')
$ResultPath = Join-Path $env:TEMP ('RIAS-Test-Result-' + [Guid]::NewGuid().ToString('N') + '.txt')
try {
    [IO.File]::WriteAllText($PromptPath, 'Reponds uniquement par IA_LOCALE_OK', (New-Object Text.UTF8Encoding($false)))
    Info 'Test d une vraie reponse du modele. Le premier chargement peut prendre plusieurs minutes.'
    & (Join-Path $Root 'MOTEUR_IA.bat') $PromptPath $ResultPath
    $EngineExit = $LASTEXITCODE
    $EngineText = if (Test-Path -LiteralPath $ResultPath) { [IO.File]::ReadAllText($ResultPath, [Text.Encoding]::UTF8) } else { '' }
    if ($EngineExit -ne 0) {
        Fail 'Generation IA locale' ('code ' + $EngineExit + ' ; ' + $EngineText.Trim())
    } elseif ($EngineText -notmatch '(?i)IA_LOCALE_OK') {
        Fail 'Generation IA locale' ('Ollama a repondu, mais pas avec le marqueur attendu. Reponse : ' + $EngineText.Trim())
    } else {
        Pass 'Generation IA locale' 'le meme moteur que l application a produit la reponse attendue'
    }
} catch {
    Fail 'Generation IA locale' $_.Exception.Message
} finally {
    Remove-Safely $PromptPath
    Remove-Safely $ResultPath
}

if (-not $SkipOnlineUpdate) {
    $UpdateTemp = Join-Path $env:TEMP ('RIAS-Update-Test-' + [Guid]::NewGuid().ToString('N'))
    try {
        New-Item -ItemType Directory -Path $UpdateTemp -Force | Out-Null
        $Channel = Get-Content -LiteralPath (Join-Path $Root 'update-channel.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $ManifestUri = [Uri]([string]$Channel.manifestUrl)
        if ($ManifestUri.Scheme -ne 'https') { throw 'Le manifeste ne passe pas par HTTPS.' }
        $ManifestPath = Join-Path $UpdateTemp 'manifest.json'
        Invoke-WebRequest -UseBasicParsing -Uri $ManifestUri.AbsoluteUri -OutFile $ManifestPath -TimeoutSec 60
        $Manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$Manifest.sha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Empreinte SHA-256 distante invalide.' }
        $PackageUri = [Uri]::new($ManifestUri, [string]$Manifest.packageUrl)
        if ($PackageUri.Scheme -ne 'https') { throw 'Le paquet ne passe pas par HTTPS.' }
        $PackagePath = Join-Path $UpdateTemp 'package.zip'
        Invoke-WebRequest -UseBasicParsing -Uri $PackageUri.AbsoluteUri -OutFile $PackagePath -TimeoutSec 180
        $Actual = Get-Sha256 $PackagePath
        if ($Actual -ne ([string]$Manifest.sha256).ToUpperInvariant()) { throw 'Le ZIP distant ne correspond pas a son empreinte.' }
        $ExtractPath = Join-Path $UpdateTemp 'extract'
        Expand-Archive -LiteralPath $PackagePath -DestinationPath $ExtractPath -Force
        if (-not (Test-Path -LiteralPath (Join-Path $ExtractPath 'RobloxIAStudio\RobloxIAStudio.exe'))) {
            throw 'Le ZIP distant ne contient pas l application attendue.'
        }
        Pass 'Canal de mise a jour' ('version distante ' + [string]$Manifest.latestVersion + ', ZIP telecharge et verifie')
    } catch {
        Fail 'Canal de mise a jour' $_.Exception.Message
    } finally {
        Remove-Safely $UpdateTemp
    }
} else {
    Info 'Test du canal de mise a jour ignore sur demande.'
}

Add-Line ''
if ($script:Failures -eq 0) {
    Add-Line 'RESULTAT : SUCCES COMPLET DES TESTS EXECUTABLES SUR CE PC.' Green
    Add-Line 'Roblox Studio reste a tester separement avec une Baseplate.' Yellow
} else {
    Add-Line ('RESULTAT : ' + $script:Failures + ' TEST(S) EN ECHEC. Le logiciel ne doit pas etre considere comme valide.') Red
}

try {
    [IO.File]::WriteAllLines($LogPath, $script:LogLines, (New-Object Text.UTF8Encoding($false)))
    Add-Line ('Journal : ' + $LogPath) White
} catch {
    Add-Line ('Impossible d enregistrer le journal : ' + $_.Exception.Message) Yellow
}

if ($script:Failures -eq 0) { exit 0 }
exit 1

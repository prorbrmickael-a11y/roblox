@echo off
setlocal
cd /d "%~dp0"
title Diagnostic Roblox IA Studio
echo Demarrage de RIAS Creator Studio 4.2.1...
echo.
start "" /wait "%~dp0RobloxIAStudio.exe"
set "RIAS_EXIT=%ERRORLEVEL%"
echo.
echo L'application s'est fermee avec le code : %RIAS_EXIT%
if not "%RIAS_EXIT%"=="0" (
  echo Copiez ce code et envoyez-le dans la conversation pour poursuivre le diagnostic.
)
echo.
pause
exit /b %RIAS_EXIT%

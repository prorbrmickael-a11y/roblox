param(
    [Parameter(Mandatory = $true)]
    [string]$PromptPath,

    [Parameter(Mandatory = $true)]
    [string]$ResultPath,

    [int]$ServerWaitSeconds = 60,
    [int]$RequestTimeoutSeconds = 3600
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$ApiBase = 'http://127.0.0.1:11434'
$ModelName = 'roblox-ai-studio'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Result([string]$Text) {
    [IO.File]::WriteAllText($ResultPath, $Text, $Utf8NoBom)
}

function Stop-WithError([int]$Code, [string]$Message) {
    try { Write-Result ('ERREUR_IA=' + $Message) } catch { }
    exit $Code
}

function Find-Ollama {
    $Command = Get-Command 'ollama.exe' -ErrorAction SilentlyContinue
    if ($Command -and $Command.Source) { return $Command.Source }

    $Candidates = @()
    if ($env:LOCALAPPDATA) {
        $Candidates += (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe')
        $Candidates += (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe')
    }
    if ($env:ProgramFiles) {
        $Candidates += (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
    }
    foreach ($Candidate in $Candidates) {
        if (Test-Path -LiteralPath $Candidate -PathType Leaf) { return $Candidate }
    }
    return $null
}

function Get-Models {
    return Invoke-RestMethod -UseBasicParsing -Method Get -Uri ($ApiBase + '/api/tags') -TimeoutSec 5
}

function Wait-Ollama([int]$Seconds) {
    $Deadline = (Get-Date).AddSeconds($Seconds)
    do {
        try { return Get-Models } catch { Start-Sleep -Milliseconds 750 }
    } while ((Get-Date) -lt $Deadline)
    return $null
}

if (-not (Test-Path -LiteralPath $PromptPath -PathType Leaf)) {
    Stop-WithError 20 'Le fichier contenant la demande est introuvable.'
}

try {
    $Prompt = [IO.File]::ReadAllText($PromptPath, [Text.Encoding]::UTF8)
} catch {
    Stop-WithError 21 ('Impossible de lire la demande : ' + $_.Exception.Message)
}
if ([string]::IsNullOrWhiteSpace($Prompt)) {
    Stop-WithError 22 'La demande envoyee au moteur IA est vide.'
}

$Models = $null
try { $Models = Get-Models } catch { }
if (-not $Models) {
    $OllamaExe = Find-Ollama
    if (-not $OllamaExe) {
        Stop-WithError 10 'Ollama est introuvable. Lance INSTALLER_IA_LOCALE.bat puis recommence.'
    }
    try {
        Start-Process -FilePath $OllamaExe -ArgumentList @('serve') -WindowStyle Hidden | Out-Null
    } catch {
        Stop-WithError 11 ('Ollama est installe mais son serveur ne demarre pas : ' + $_.Exception.Message)
    }
    $Models = Wait-Ollama $ServerWaitSeconds
    if (-not $Models) {
        Stop-WithError 11 ('Le serveur Ollama ne repond pas apres ' + $ServerWaitSeconds + ' secondes.')
    }
}

$Installed = @($Models.models | ForEach-Object {
    if ($_.name) { [string]$_.name }
    elseif ($_.model) { [string]$_.model }
})
$HasModel = $false
foreach ($Name in $Installed) {
    if ($Name -eq $ModelName -or $Name -eq ($ModelName + ':latest')) {
        $HasModel = $true
        break
    }
}
if (-not $HasModel) {
    Stop-WithError 12 'Le profil roblox-ai-studio est absent. Relance INSTALLER_IA_LOCALE.bat jusqu au test final reussi.'
}

try {
    $Payload = @{
        model = $ModelName
        prompt = $Prompt
        stream = $false
        think = $false
        keep_alive = '10m'
        options = @{
            num_ctx = 16384
            temperature = 0.25
            top_p = 0.9
        }
    } | ConvertTo-Json -Depth 6 -Compress
    $Body = [Text.Encoding]::UTF8.GetBytes($Payload)
    $Reply = Invoke-RestMethod -UseBasicParsing -Method Post -Uri ($ApiBase + '/api/generate') `
        -ContentType 'application/json; charset=utf-8' -Body $Body -TimeoutSec $RequestTimeoutSeconds
} catch {
    Stop-WithError 13 ('La generation Ollama a echoue : ' + $_.Exception.Message)
}

if (-not $Reply -or [string]::IsNullOrWhiteSpace([string]$Reply.response)) {
    Stop-WithError 14 'Ollama a termine sans produire de reponse exploitable.'
}

try {
    Write-Result ([string]$Reply.response)
} catch {
    Stop-WithError 15 ('Impossible d enregistrer la reponse IA : ' + $_.Exception.Message)
}

exit 0

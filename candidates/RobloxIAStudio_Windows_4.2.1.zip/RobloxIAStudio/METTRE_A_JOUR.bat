@echo off
setlocal
chcp 65001 >nul
title Mise a jour - Roblox IA Studio
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0Updater\Update.ps1" -CurrentVersion "4.2.1"
set "RIAS_UPDATE_EXIT=%ERRORLEVEL%"
if not "%RIAS_UPDATE_EXIT%"=="0" (
  echo.
  echo La mise a jour n'a pas pu etre terminee. L'ancienne version a ete conservee.
  pause
)
exit /b %RIAS_UPDATE_EXIT%

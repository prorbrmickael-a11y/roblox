param(
    [Parameter(Mandatory = $true)]
    [string]$CurrentVersion
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$AppDir = Split-Path -Parent $PSScriptRoot
$AppExe = Join-Path $AppDir "RobloxIAStudio.exe"
$ChannelFile = Join-Path $AppDir "update-channel.json"
$TempRoot = Join-Path ([IO.Path]::GetTempPath()) ("RIAS-Update-" + [Guid]::NewGuid().ToString("N"))
$ShouldRelaunch = Test-Path -LiteralPath $AppExe

function Write-Step([string]$Text) {
    Write-Host ("[Roblox IA Studio] " + $Text) -ForegroundColor Cyan
}

function Start-App {
    if ($ShouldRelaunch -and (Test-Path -LiteralPath $AppExe)) {
        Start-Process -FilePath $AppExe -WorkingDirectory $AppDir | Out-Null
    }
}

function Resolve-Manifest {
    if (-not (Test-Path -LiteralPath $ChannelFile)) {
        throw "Le fichier update-channel.json est introuvable."
    }
    $channel = Get-Content -LiteralPath $ChannelFile -Raw | ConvertFrom-Json
    if ($channel.manifestUrl) {
        $uri = [Uri]$channel.manifestUrl
        if ($uri.Scheme -ne "https") {
            throw "Le canal distant doit utiliser HTTPS."
        }
        $target = Join-Path $TempRoot "manifest.json"
        Invoke-WebRequest -UseBasicParsing -Uri $uri.AbsoluteUri -OutFile $target
        return @{ Path = $target; RemoteUri = $uri }
    }
    if (-not $channel.localManifest) {
        throw "Aucun canal de mise a jour stable n'est configure."
    }
    $local = Join-Path $AppDir ([string]$channel.localManifest)
    if (-not (Test-Path -LiteralPath $local)) {
        throw "Le canal de mise a jour local est introuvable."
    }
    return @{ Path = $local; RemoteUri = $null }
}

function Resolve-Package([object]$Manifest, [object]$Source, [string]$Destination) {
    $package = [string]$Manifest.packageUrl
    if ([string]::IsNullOrWhiteSpace($package)) {
        throw "Le manifeste ne contient pas de paquet de mise a jour."
    }
    $absolute = $null
    if ([Uri]::TryCreate($package, [UriKind]::Absolute, [ref]$absolute)) {
        if ($absolute.Scheme -ne "https") {
            throw "Le paquet distant doit utiliser HTTPS."
        }
        Invoke-WebRequest -UseBasicParsing -Uri $absolute.AbsoluteUri -OutFile $Destination
        return
    }
    if ($Source.RemoteUri) {
        $resolved = [Uri]::new($Source.RemoteUri, $package)
        if ($resolved.Scheme -ne "https") {
            throw "Le paquet distant doit utiliser HTTPS."
        }
        Invoke-WebRequest -UseBasicParsing -Uri $resolved.AbsoluteUri -OutFile $Destination
        return
    }
    $local = Join-Path (Split-Path -Parent $Source.Path) $package
    if (-not (Test-Path -LiteralPath $local)) {
        throw "Le paquet indique par le manifeste est introuvable."
    }
    Copy-Item -LiteralPath $local -Destination $Destination -Force
}

try {
    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    Write-Step "Verification du canal stable..."
    $source = Resolve-Manifest
    $manifest = Get-Content -LiteralPath $source.Path -Raw | ConvertFrom-Json
    if (-not $manifest.latestVersion) {
        throw "Le manifeste ne contient pas latestVersion."
    }
    $current = [Version]$CurrentVersion
    $latest = [Version]([string]$manifest.latestVersion)
    if ($latest -le $current) {
        Write-Step ("La version " + $CurrentVersion + " est deja a jour.")
        Start-Sleep -Seconds 2
        Start-App
        exit 0
    }
    if (([string]$manifest.sha256) -notmatch '^[0-9a-fA-F]{64}$') {
        throw "La signature SHA-256 du paquet est absente ou invalide."
    }

    $zipPath = Join-Path $TempRoot "update.zip"
    $extractDir = Join-Path $TempRoot "payload"
    $backupDir = Join-Path $TempRoot "backup"
    Write-Step ("Telechargement de la version " + $latest.ToString() + "...")
    Resolve-Package -Manifest $manifest -Source $source -Destination $zipPath
    $actualHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
    if ($actualHash -ne ([string]$manifest.sha256).ToUpperInvariant()) {
        throw "Le paquet telecharge ne correspond pas a sa signature SHA-256."
    }

    New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
    $payload = Join-Path $extractDir "RobloxIAStudio"
    if (-not (Test-Path -LiteralPath (Join-Path $payload "RobloxIAStudio.exe"))) {
        throw "Le paquet ne contient pas l'application attendue."
    }
    if (-not (Test-Path -LiteralPath (Join-Path $payload "Updater\Update.ps1"))) {
        throw "Le paquet ne contient pas le module de mise a jour."
    }

    Write-Step "Fermeture de l'application..."
    $limit = (Get-Date).AddSeconds(30)
    while ((Get-Process -Name "RobloxIAStudio" -ErrorAction SilentlyContinue) -and (Get-Date) -lt $limit) {
        Start-Sleep -Milliseconds 500
    }
    if (Get-Process -Name "RobloxIAStudio" -ErrorAction SilentlyContinue) {
        throw "L'application ne s'est pas fermee. Fermez-la puis recommencez."
    }

    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    $installedFiles = @()
    Get-ChildItem -LiteralPath $payload -File -Recurse | ForEach-Object {
        $relative = $_.FullName.Substring($payload.Length).TrimStart('\')
        $target = Join-Path $AppDir $relative
        if (Test-Path -LiteralPath $target) {
            $backup = Join-Path $backupDir $relative
            New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
            Copy-Item -LiteralPath $target -Destination $backup -Force
        }
        $installedFiles += $target
    }

    try {
        Write-Step "Installation et verification..."
        Copy-Item -Path (Join-Path $payload '*') -Destination $AppDir -Recurse -Force
        if (-not (Test-Path -LiteralPath $AppExe)) {
            throw "L'executable est absent apres installation."
        }
    }
    catch {
        Write-Host "Restauration automatique de la version precedente..." -ForegroundColor Yellow
        if (Test-Path -LiteralPath $backupDir) {
            Copy-Item -Path (Join-Path $backupDir '*') -Destination $AppDir -Recurse -Force
        }
        throw
    }

    Write-Step ("Mise a jour terminee : version " + $latest.ToString())
    Start-Sleep -Seconds 2
    Start-App
    exit 0
}
catch {
    Write-Host ""
    Write-Host ("ERREUR : " + $_.Exception.Message) -ForegroundColor Red
    Start-App
    exit 1
}
finally {
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

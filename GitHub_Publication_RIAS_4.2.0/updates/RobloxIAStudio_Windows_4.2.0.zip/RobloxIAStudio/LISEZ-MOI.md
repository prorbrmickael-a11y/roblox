# RIAS Creator Studio 4.2.0

Studio de création Windows 64 bits centré sur une seule action : décrire une idée, puis laisser l'équipe IA construire le premier jeu.

La version 4.2 introduit une interface entièrement redessinée : navigation structurée, cartes visuelles, actions hiérarchisées, thème sombre professionnel et parcours de création plus clair.

## Installer l'intelligence artificielle

1. Décompressez entièrement l'archive.
2. Double-cliquez sur `INSTALLER_IA_LOCALE.bat`.
3. Laissez l'installation télécharger Ollama et `Qwen 3.5 9B` — environ 6,6 Go — puis créer le profil optimisé `roblox-ai-studio`.
4. Lancez ensuite `RobloxIAStudio.exe`.

Si le bouton **Lancer l'équipe IA autonome** ne répond pas, double-cliquez sur `TESTER_IA_LOCALE.bat`. Il vérifie le chemin d'Ollama, la présence du profil et affiche immédiatement l'erreur exacte.

La génération fonctionne ensuite localement et gratuitement. Une connexion Internet n'est requise que pour télécharger Ollama et le modèle. Windows 10/11 64 bits et 16 Go de RAM sont recommandés ; sans carte graphique compatible, la génération fonctionne sur le processeur mais sera plus lente.

## Lancer l'application

1. Décompressez entièrement l'archive ZIP.
2. Après l'installation du modèle, double-cliquez sur `RobloxIAStudio.exe`.
3. Windows SmartScreen peut afficher un avertissement parce que l'exécutable n'est pas signé. Cliquez sur **Informations complémentaires**, puis **Exécuter quand même** uniquement si le fichier vient directement de cette livraison.

Aucun Python, Node.js ou abonnement n'est requis. Un compte Roblox n'est nécessaire que pour publier et connecter les données du dashboard.

Si l'application elle-même ne s'affiche pas, lancez `LANCER_AVEC_DIAGNOSTIC.bat`. Cette fenêtre attend sa fermeture et affiche son code de sortie, ce qui permet d'identifier un éventuel blocage Windows.

## Fonctionnalités

- parcours débutant « une idée → un jeu » sans paramètres obligatoires ;
- nouvelle identité visuelle RIAS Creator Studio ;
- navigation numérotée avec indication de l'espace actif ;
- boutons modernes dessinés nativement et actions principales mises en évidence ;
- écrans organisés en cartes lisibles pour séparer création, réglages, export et analytics ;
- choix automatique du genre, de la boucle de gameplay, de la map, de la progression et des systèmes adaptés au concept ;
- pipeline autonome en trois passes : conception, programmation, audit/correction ;
- génération locale avec Qwen 3.5 9B et contexte étendu à 16 384 tokens ;
- génération d'un script Luau propre au concept, au lieu d'un simple remplissage de paramètres ;
- filtrage du code distant et des primitives dangereuses avant export ;
- repli automatique sur le générateur sécurisé intégré si le code libre est refusé ;
- validation automatique de la réponse de l'IA ;
- détection d'Ollama même lorsque Windows n'a pas encore actualisé son `PATH` ;
- diagnostic visible dans le chat si Ollama ou le modèle ne démarre pas ;
- création en un clic du game design, de l'économie, du monde et de la feuille de route ;
- création et ouverture de projets `.rias` ;
- configuration du biome, de la taille, des îles et de la ressource ;
- réglage de la récolte, de la transformation, des ventes et des améliorations ;
- notes de feuille de route conservées avec le projet ;
- export d'un script Luau côté serveur ;
- génération du monde, des ressources, des stations et de la progression ;
- validation serveur, délais anti-spam et sauvegarde DataStore optionnelle.
- plugin Studio avec construction persistante de la map en mode édition ;
- génération d'assets procéduraux natifs : arbres, rochers, lampes, matériaux et éclairage ;
- installation automatique du gameplay et de la télémétrie ;
- lancement/arrêt des tests et capture des erreurs depuis le plugin ;
- dashboard local multi-jeux pour l'audience, les revenus et le marketing ;
- connexion Open Cloud avec clé chiffrée par Windows ;
- import et agrégation locale des CSV de ventes Roblox.
- bouton **Mettre à jour** intégré, avec téléchargement HTTPS, contrôle SHA-256, sauvegarde de secours et redémarrage automatique ;
- canal local de secours qui confirme que la version installée est à jour, même avant l'activation du canal Internet officiel.

## Mettre l'application à jour

Cliquez sur **Mettre à jour** dans la barre de gauche. L'application vérifie le canal stable, contrôle l'intégrité du paquet, ferme la version actuelle, installe les nouveaux fichiers et redémarre automatiquement. En cas d'échec pendant la copie, les fichiers précédents sont restaurés.

La version 4.2.0 est reliée au canal public stable `prorbrmickael-a11y/roblox`. Les prochaines versions seront détectées et téléchargées depuis ce dépôt avec le bouton **Mettre à jour**. Le moteur refuse les canaux non chiffrés et les paquets sans empreinte SHA-256 valide.

## Installer et utiliser le plugin Roblox Studio

1. Fermez Roblox Studio puis lancez `INSTALLER_PLUGIN_STUDIO.bat`.
2. Dans l'application, générez votre jeu et exportez `RobloxIA_Game.server.lua`.
3. Ouvrez une Baseplate ou votre projet dans Roblox Studio.
4. Dans l'onglet **Plugins**, cliquez sur **Studio IA**.
5. Collez le contenu du script exporté dans le plugin.
6. Cliquez sur **Construire la map et installer le jeu**.
7. Vérifiez le monde éditable, puis cliquez sur **Lancer le test**.

Le plugin crée `RIAS_GeneratedWorld`, `RIAS_Game` et `RIAS_Telemetry`. Ses modifications utilisent `ChangeHistoryService` et restent annulables avec `Ctrl+Z`. Pendant un test, le script remplace sa copie temporaire du monde afin d'éviter les doublons, sans effacer la map enregistrée dans l'éditeur.

Pour tester la sauvegarde dans Studio, activez **Game Settings → Security → Enable Studio Access to API Services** sur une expérience de test. Ne l'activez pas sur une expérience de production partagée sans comprendre les effets sur les données.

## Utiliser le dashboard créateur

1. Dans l'application, ouvrez **Pilotage & Analytics** puis **Ouvrir le dashboard**.
2. Dans **Réglages**, ajoutez le nom du jeu et son `Universe ID`.
3. Créez une clé Roblox Open Cloud limitée à la lecture du DataStore `RIAS_Analytics`, puis enregistrez-la. Elle est chiffrée par Windows pour l'utilisateur courant.
4. Après publication et collecte de données, cliquez sur **Synchroniser**.
5. Pour les revenus, téléchargez le CSV Roblox **Sales of Goods** et utilisez **Importer CSV Roblox**.

Le dashboard affiche uniquement des données réelles. Les lignes de vente sont agrégées dans le navigateur et les identifiants acheteurs ne sont pas conservés.

## Limites connues

- Windows 10/11 64 bits uniquement ;
- la publication publique reste une action volontaire du créateur ;
- les assets visuels personnalisés comme les meshes, textures, sons et animations doivent encore être importés ou créés séparément ;
- toutes les métriques financières Roblox ne disposent pas d'une API publique : les ventes utilisent donc l'export CSV officiel ;
- l'équipe IA peut inventer différentes familles de gameplay, mais le générateur de secours utilise la boucle fiable « récolter → transformer → vendre → améliorer » ;
- un modèle local peut parfois produire une réponse incomplète : l'application la refuse et demande de relancer la génération ;
- les projets générés doivent être testés dans Roblox Studio avant publication ;
- l'exécutable n'est pas signé numériquement dans cette version gratuite.

## Confidentialité

Les concepts et les projets restent sur votre ordinateur. Ollama exécute le modèle localement ; l'application n'envoie pas les conversations vers un service IA distant.

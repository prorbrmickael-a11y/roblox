@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Installation de l'IA locale - Roblox IA Studio 4.0.1

echo ============================================================
echo   ROBLOX IA STUDIO 4.0.1 - INSTALLATION DE L'EQUIPE IA
echo ============================================================
echo.
echo Modele : Qwen 3.5 9B Q4_K_M
echo Taille : environ 6,6 Go + Ollama
echo Conseil : Windows 10/11 64 bits, 16 Go de RAM recommandes.
echo Toutes les generations resteront ensuite sur ce PC.
echo.
pause

set "OLLAMA_EXE="
for /f "delims=" %%I in ('where ollama.exe 2^>nul') do if not defined OLLAMA_EXE set "OLLAMA_EXE=%%I"

if not defined OLLAMA_EXE if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"

if not defined OLLAMA_EXE (
  where winget.exe >nul 2>&1
  if errorlevel 1 goto :NO_WINGET
  echo Installation officielle d'Ollama...
  winget install --id Ollama.Ollama --exact --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :INSTALL_FAILED
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
)

if not defined OLLAMA_EXE goto :INSTALL_FAILED

echo.
echo Telechargement de Qwen 3.5 9B. Ne fermez pas cette fenetre.
echo Cette etape peut etre longue selon la connexion Internet.
"%OLLAMA_EXE%" pull qwen3.5:9b
if errorlevel 1 goto :MODEL_FAILED

echo.
echo Verification du modele...
"%OLLAMA_EXE%" show qwen3.5:9b >nul
if errorlevel 1 goto :MODEL_FAILED

echo.
echo Optimisation du modele pour la programmation Roblox...
set "RIAS_MODELFILE=%TEMP%\RobloxIAStudio_Modelfile.txt"
>"%RIAS_MODELFILE%" echo FROM qwen3.5:9b
>>"%RIAS_MODELFILE%" echo PARAMETER num_ctx 16384
>>"%RIAS_MODELFILE%" echo PARAMETER temperature 0.25
>>"%RIAS_MODELFILE%" echo PARAMETER top_p 0.9
"%OLLAMA_EXE%" create roblox-ai-studio -f "%RIAS_MODELFILE%"
if errorlevel 1 goto :MODEL_FAILED
del "%RIAS_MODELFILE%" >nul 2>&1

"%OLLAMA_EXE%" show roblox-ai-studio >nul
if errorlevel 1 goto :MODEL_FAILED

echo.
echo ============================================================
echo Installation terminee avec succes.
echo Le profil roblox-ai-studio est pret avec un contexte de 16 384 tokens.
echo Tu peux maintenant lancer RobloxIAStudio.exe.
echo ============================================================
pause
exit /b 0

:NO_WINGET
echo.
echo Winget n'est pas disponible sur ce PC.
echo Installe Ollama depuis https://ollama.com/download/windows
echo puis relance ce fichier.
pause
exit /b 2

:INSTALL_FAILED
echo.
echo L'installation d'Ollama a echoue.
echo Installe-le depuis https://ollama.com/download/windows puis relance ce fichier.
pause
exit /b 3

:MODEL_FAILED
echo.
echo Le telechargement du modele a echoue ou a ete interrompu.
echo Verifie l'espace disque et la connexion, puis relance ce fichier.
pause
exit /b 4

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataRoot = Join-Path $env:LOCALAPPDATA 'RobloxIAStudio'
$ConfigPath = Join-Path $DataRoot 'dashboard-config.json'
New-Item -ItemType Directory -Path $DataRoot -Force | Out-Null

function Send-Json($Context, $Object, $Status = 200) {
    $Json = $Object | ConvertTo-Json -Depth 12 -Compress
    $Bytes = [Text.Encoding]::UTF8.GetBytes($Json)
    $Context.Response.StatusCode = $Status
    $Context.Response.ContentType = 'application/json; charset=utf-8'
    $Context.Response.ContentLength64 = $Bytes.Length
    $Context.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
    $Context.Response.Close()
}

function Read-Body($Request) {
    $Reader = New-Object IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    try { return $Reader.ReadToEnd() } finally { $Reader.Dispose() }
}

function Load-Config {
    if (-not (Test-Path $ConfigPath)) { return [pscustomobject]@{ apiKeyEncrypted = ''; games = @() } }
    try { return Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { return [pscustomobject]@{ apiKeyEncrypted = ''; games = @() } }
}

function Get-ApiKey($Config) {
    if (-not $Config.apiKeyEncrypted) { return '' }
    try {
        $Secure = ConvertTo-SecureString $Config.apiKeyEncrypted
        return ([pscredential]::new('rias', $Secure)).GetNetworkCredential().Password
    } catch { return '' }
}

function Save-Config($Payload) {
    $Current = Load-Config
    $Encrypted = $Current.apiKeyEncrypted
    if ($Payload.apiKey) {
        $Secure = ConvertTo-SecureString ([string]$Payload.apiKey) -AsPlainText -Force
        $Encrypted = ConvertFrom-SecureString $Secure
    }
    $Games = @($Payload.games | ForEach-Object {
        [pscustomobject]@{ name = [string]$_.name; universeId = [string]$_.universeId }
    } | Where-Object { $_.name -and $_.universeId })
    [pscustomobject]@{ apiKeyEncrypted = $Encrypted; games = $Games } |
        ConvertTo-Json -Depth 6 | Set-Content $ConfigPath -Encoding UTF8
}

function Get-Telemetry($UniverseId) {
    if ($UniverseId -notmatch '^\d+$') { throw 'Universe ID invalide.' }
    $Config = Load-Config
    $ApiKey = Get-ApiKey $Config
    if (-not $ApiKey) { throw 'Ajoute une clé Open Cloud dans Réglages.' }
    $Headers = @{ 'x-api-key' = $ApiKey }
    $Base = "https://apis.roblox.com/cloud/v2/universes/$UniverseId/data-stores/RIAS_Analytics/entries"
    $List = Invoke-RestMethod -Method Get -Uri ($Base + '?maxPageSize=100') -Headers $Headers
    $Rows = @()
    function Metric($Payload, $Name) {
        if ($Payload.value -and $null -ne $Payload.value.$Name) { return [double]$Payload.value.$Name }
        if ($null -ne $Payload.$Name) { return [double]$Payload.$Name }
        return 0
    }
    foreach ($Entry in @($List.dataStoreEntries)) {
        $Path = [string]$Entry.path
        if (-not $Path -or $Path -notmatch 'day') { continue }
        try {
            $Uri = if ($Path.StartsWith('http')) { $Path } else { 'https://apis.roblox.com/cloud/v2/' + $Path.TrimStart('/') }
            $Value = Invoke-RestMethod -Method Get -Uri $Uri -Headers $Headers
            $Id = if ($Entry.id) { [string]$Entry.id } else { [Uri]::UnescapeDataString(($Path -split '/')[-1]) }
            if ($Id.StartsWith('day:')) {
                $Rows += [pscustomobject]@{
                    date = $Id.Substring(4)
                    joins = Metric $Value 'joins'
                    uniquePlayers = Metric $Value 'uniquePlayers'
                    sessions = Metric $Value 'sessions'
                    sessionSeconds = Metric $Value 'sessionSeconds'
                }
            }
        } catch { }
    }
    return @($Rows | Sort-Object date)
}

$Port = 49152
while ($Port -lt 49164) {
    $Listener = New-Object Net.HttpListener
    $Listener.Prefixes.Add("http://127.0.0.1:$Port/")
    try { $Listener.Start(); break } catch { $Listener.Close(); $Port++ }
}
if (-not $Listener.IsListening) { throw 'Aucun port local disponible.' }

$Url = "http://127.0.0.1:$Port/"
Write-Host "Dashboard Roblox IA Studio : $Url"
Write-Host 'Ferme cette fenêtre pour arrêter le dashboard.'
Start-Process $Url

try {
    while ($Listener.IsListening) {
        $Context = $Listener.GetContext()
        try {
            $Path = $Context.Request.Url.AbsolutePath
            if ($Path -eq '/api/config' -and $Context.Request.HttpMethod -eq 'GET') {
                $Config = Load-Config
                Send-Json $Context ([pscustomobject]@{ games = @($Config.games); hasApiKey = [bool]$Config.apiKeyEncrypted })
                continue
            }
            if ($Path -eq '/api/config' -and $Context.Request.HttpMethod -eq 'POST') {
                $Payload = Read-Body $Context.Request | ConvertFrom-Json
                Save-Config $Payload
                Send-Json $Context @{ ok = $true }
                continue
            }
            if ($Path -eq '/api/telemetry' -and $Context.Request.HttpMethod -eq 'GET') {
                $UniverseId = $Context.Request.QueryString['universeId']
                Send-Json $Context @{ rows = @(Get-Telemetry $UniverseId) }
                continue
            }
            if ($Path.StartsWith('/api/')) {
                Send-Json $Context @{ error = 'Route inconnue.' } 404
                continue
            }
            $Relative = if ($Path -eq '/') { 'index.html' } else { $Path.TrimStart('/') }
            $SafeName = [IO.Path]::GetFileName($Relative)
            $File = Join-Path $Root $SafeName
            if (-not (Test-Path $File)) { Send-Json $Context @{ error = 'Fichier introuvable.' } 404; continue }
            $Bytes = [IO.File]::ReadAllBytes($File)
            $Context.Response.StatusCode = 200
            $Context.Response.ContentType = if ($File.EndsWith('.html')) { 'text/html; charset=utf-8' } elseif ($File.EndsWith('.js')) { 'application/javascript; charset=utf-8' } else { 'text/plain; charset=utf-8' }
            $Context.Response.ContentLength64 = $Bytes.Length
            $Context.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
            $Context.Response.Close()
        } catch {
            if ($Context.Response.OutputStream.CanWrite) { Send-Json $Context @{ error = $_.Exception.Message } 500 }
        }
    }
} finally {
    $Listener.Stop()
    $Listener.Close()
}

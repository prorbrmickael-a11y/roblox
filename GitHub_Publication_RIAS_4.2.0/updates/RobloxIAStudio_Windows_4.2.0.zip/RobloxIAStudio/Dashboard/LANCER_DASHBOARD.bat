@echo off
setlocal
cd /d "%~dp0"
title Roblox IA Studio - Dashboard
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DashboardServer.ps1"
if errorlevel 1 (
  echo.
  echo Le dashboard n'a pas pu demarrer.
  pause
)

# Journal des versions

## 4.2.0

- Nouvelle identité **RIAS Creator Studio**.
- Refonte complète de l'interface avec thème sombre professionnel et accent violet.
- Navigation numérotée, état actif visible et section application séparée.
- Boutons natifs dessinés sur mesure avec variantes principales, secondaires et désactivées.
- Cartes visuelles pour organiser chaque étape du travail.
- Écran d'accueil recentré sur une promesse simple : transformer une idée en jeu Roblox.
- Libellés, réglages avancés, export, plugin et analytics réécrits pour être plus clairs et convaincants.
- Aucune nouvelle dépendance : l'interface reste intégrée à l'exécutable Windows autonome.
- Activation du canal de mise à jour public GitHub `prorbrmickael-a11y/roblox`.

## 4.1.0

- Écran principal recentré sur la seule information demandée à l'utilisateur : son idée de jeu.
- Le directeur créatif déduit maintenant le genre, la boucle principale, l'objectif, la map, les systèmes, le tutoriel, la rétention et la monétisation éthique.
- Le programmeur IA ne force plus la boucle récolte → transformation → vente quand le concept demande un autre genre.
- Conservation du brief complet entre la conception et la programmation.
- Ajout du bouton **Mettre à jour** dans l'application.
- Mise à jour HTTPS avec contrôle SHA-256 obligatoire, installation par surcouche, sauvegarde de secours, restauration automatique et redémarrage.
- Ajout d'un canal local permettant de vérifier immédiatement le fonctionnement du bouton avant l'ouverture du canal Internet officiel.

## 4.0.1

- Correction du lancement de l'équipe IA lorsque Windows n'a pas encore ajouté Ollama au `PATH`.
- Résolution fiable de tous les fichiers auxiliaires depuis le dossier réel de l'application.
- Vérification explicite de la présence du profil `roblox-ai-studio` avant génération.
- Affichage dans le chat de l'erreur réelle d'Ollama au lieu d'un message générique.
- Ajout de `TESTER_IA_LOCALE.bat` pour valider le moteur en un double-clic.

## 4.0.0

- Plugin Roblox Studio local avec construction éditable de la map.
- Pack d'assets procéduraux natifs : arbres, rochers, éclairage et décor.
- Installation automatique du gameplay et de la télémétrie dans ServerScriptService.
- Tests Studio, capture des erreurs et suppression annulable avec Ctrl+Z.
- Dashboard créateur local avec portfolio multi-jeux et connexion Open Cloud.
- Analyse des joueurs, sessions, revenus, produits, conversion, ARPDAU et ARPPU.
- Import local des CSV Roblox sans conservation des identifiants acheteurs.
- Recommandations marketing calculées uniquement à partir des données réelles.
- Clé Open Cloud chiffrée par Windows et jamais intégrée au jeu.

## 3.0.0

- Nouvelle équipe IA autonome : directeur créatif, programmeur Luau et auditeur/correcteur.
- Génération d'un script Roblox complet et spécifique au concept.
- Profil Ollama optimisé avec contexte de 16 384 tokens et température réduite.
- Contrôles locaux bloquant le code distant et les primitives dangereuses.
- Repli automatique sur le moteur déterministe sécurisé si une génération est refusée.
- Export du code audité en priorité, sans supprimer le mode manuel avancé.

## 2.0.0

- Nouvel assistant de conception en langage naturel.
- Intégration locale de Qwen 3.5 9B avec Ollama.
- Transformation automatique d'un concept en paramètres de monde, économie, progression et LiveOps.
- Validation stricte de la sortie IA avant modification du projet.
- Export immédiat du jeu depuis l'assistant.
- Installation guidée du moteur IA et du modèle de 6,6 Go.

## 1.0.1

- Correction critique du démarrage : reconstruction correcte des adresses internes de l'exécutable Windows.
- Ajout d'un lanceur de diagnostic avec code de sortie visible.
- Ajout d'une vérification automatisée empêchant la réapparition de ce défaut.

## 1.0.0

- Première application Windows native et autonome.
- Cinq espaces : vue d'ensemble, monde, gameplay, feuille de route et export.
- Format de projet local `.rias`.
- Générateur Luau avec boucle récolte → transformation → vente → amélioration.
- Sauvegarde DataStore optionnelle et validation des interactions côté serveur.

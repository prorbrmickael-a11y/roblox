@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Installation du plugin Roblox IA Studio 4.0

echo ============================================================
echo   ROBLOX IA STUDIO 4.0 - PLUGIN ROBLOX STUDIO
echo ============================================================
echo.
echo Ce plugin peut modifier le projet actuellement ouvert dans Studio.
echo Ferme Roblox Studio avant de poursuivre.
echo Les modifications du plugin restent annulables avec Ctrl+Z.
echo.
pause

if not exist "%~dp0RobloxIAStudioPlugin.rbxmx" goto :MISSING
set "PLUGIN_DIR=%LOCALAPPDATA%\Roblox\Plugins"
if not exist "%PLUGIN_DIR%" mkdir "%PLUGIN_DIR%"
if errorlevel 1 goto :FAILED

copy /y "%~dp0RobloxIAStudioPlugin.rbxmx" "%PLUGIN_DIR%\RobloxIAStudioPlugin.rbxmx" >nul
if errorlevel 1 goto :FAILED

echo.
echo Installation terminee.
echo 1. Ouvre Roblox Studio.
echo 2. Ouvre une Baseplate ou ton projet.
echo 3. Dans Plugins, clique sur Studio IA.
echo 4. Colle le script exporte, puis clique sur Construire.
echo.
pause
exit /b 0

:MISSING
echo Fichier RobloxIAStudioPlugin.rbxmx introuvable.
echo Decompresse entierement l'archive avant l'installation.
pause
exit /b 2

:FAILED
echo L'installation a echoue. Verifie que Roblox Studio est ferme.
pause
exit /b 3

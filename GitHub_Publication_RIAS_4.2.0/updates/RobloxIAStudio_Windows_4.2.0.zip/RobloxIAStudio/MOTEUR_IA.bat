@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if "%~1"=="" exit /b 20
if "%~2"=="" exit /b 21

set "OLLAMA_EXE="
for /f "delims=" %%I in ('where ollama.exe 2^>nul') do if not defined OLLAMA_EXE set "OLLAMA_EXE=%%I"
if not defined OLLAMA_EXE if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"

if not defined OLLAMA_EXE (
  >"%~2" echo ERREUR_IA=Ollama est introuvable. Lance INSTALLER_IA_LOCALE.bat, termine l'installation, puis reessaie.
  exit /b 10
)

"%OLLAMA_EXE%" show roblox-ai-studio >nul 2>&1
if errorlevel 1 (
  start "" /b "%OLLAMA_EXE%" serve >nul 2>&1
  timeout /t 4 /nobreak >nul 2>&1
  "%OLLAMA_EXE%" show roblox-ai-studio >nul 2>&1
  if errorlevel 1 (
    >"%~2" echo ERREUR_IA=Le profil roblox-ai-studio est absent ou Ollama ne demarre pas. Relance INSTALLER_IA_LOCALE.bat.
    exit /b 11
  )
)

"%OLLAMA_EXE%" run roblox-ai-studio < "%~1" > "%~2" 2>&1
if errorlevel 1 (
  if not exist "%~2" >"%~2" echo ERREUR_IA=Ollama a echoue sans fournir de detail. Relance TESTER_IA_LOCALE.bat.
  exit /b 12
)

exit /b 0

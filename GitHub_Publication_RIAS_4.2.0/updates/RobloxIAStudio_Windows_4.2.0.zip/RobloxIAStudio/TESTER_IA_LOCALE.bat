@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Test de l'IA locale - Roblox IA Studio 4.0.1

set "RIAS_TEST_PROMPT=%TEMP%\RIAS_test_prompt_%RANDOM%.txt"
set "RIAS_TEST_RESULT=%TEMP%\RIAS_test_result_%RANDOM%.txt"
>"%RIAS_TEST_PROMPT%" echo Reponds uniquement par IA_LOCALE_OK

echo Verification d'Ollama et du profil roblox-ai-studio...
echo Le premier demarrage du modele peut prendre une ou deux minutes.
echo.
call "%~dp0MOTEUR_IA.bat" "%RIAS_TEST_PROMPT%" "%RIAS_TEST_RESULT%"
set "RIAS_TEST_EXIT=%ERRORLEVEL%"

if exist "%RIAS_TEST_RESULT%" type "%RIAS_TEST_RESULT%"
echo.
if "%RIAS_TEST_EXIT%"=="0" (
  echo SUCCES : le moteur IA local fonctionne.
  echo Tu peux fermer cette fenetre et relancer l'equipe IA autonome.
) else (
  echo ECHEC : code %RIAS_TEST_EXIT%.
  echo Le message ci-dessus indique la correction a effectuer.
)

del "%RIAS_TEST_PROMPT%" >nul 2>&1
del "%RIAS_TEST_RESULT%" >nul 2>&1
echo.
pause
exit /b %RIAS_TEST_EXIT%
